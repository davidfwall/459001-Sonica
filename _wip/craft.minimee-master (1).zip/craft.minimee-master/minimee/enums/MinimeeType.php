<?php
namespace Craft;

class MinimeeType
{
	const Css = 'css';
	const Js = 'js';
}
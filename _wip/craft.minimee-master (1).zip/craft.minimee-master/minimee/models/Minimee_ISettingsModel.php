<?php
namespace Craft;

interface Minimee_ISettingsModel
{
	public function __toString();

	public function useResourceCache();
}
